library(ggplot2)
library(tidyverse)
library(Rcmdr)
library(dunn.test)
library(gridExtra)
library(reshape2)
df = read.csv('data/data.csv')

# Research Question 1
### How much does transfer learning improve over typical non-transfer learning?

# Plot the score distribution of the scores per model
p1 = ggplot(df, aes(score, colour=model)) + geom_density() + labs(title='Distribution of Score per Model')
p1
ggsave('pre_modelscore.png')

p2 = ggplot(df, aes(score, colour=TeD)) + geom_density() + labs(title='Distribution of Score per Test Set')
p2
ggsave('pre_testset.png')

plotgrid = grid.arrange(p1,p2, nrow=1)
ggsave('pre_com.png', plot=plotgrid)

# Get unique values of the models in the data
models = levels(df$model)
B = models[1:3]
M = models[4:8]
S = models[9:9]

T = models[4:9]

df2 = data.frame(df)

# Create combined models of the Bs and the Transfer models
df2$comModel = as.character(df2$model)
df2$comModel[df2$model %in% B] = 'B'
df2$comModel[df2$model %in% M] = 'T'
df2$comModel[df2$model %in% S] = 'T'
df2$comModel = as.factor(df2$comModel)

T_set = df2[which(df2$model %in% T),]

# Plot the score distribution of the scores per combined model
ggplot(df2, aes(score, colour=comModel)) + geom_density()+ labs(title='Score Density distribution of models before (B) and after (T) transfer learning')
ggsave("rq1_combinedModel.png")

# F-test
var.test(score ~ comModel, data = df2)

mod_rq1 = lm(score ~ comModel, data=df2)
anova(mod_rq1)

tapply(X = df2$score, INDEX = list(df2$comModel), FUN = mean)
tapply(X = df2$score, INDEX = list(df2$comModel), FUN = sd)
tapply(X = df2$score, INDEX = list(df2$comModel), FUN = median)

model1 = lm(score ~ comModel, data=df2)
summary(model1)
anova(model1)

TukeyHSD(aov(score ~ comModel, df2))

ggplot(df2, aes(x=score, color=comModel)) +
  geom_histogram(fill="white", alpha=0.5, position="identity")

rq1_plot_box1 <- ggplot(df2, aes(x=comModel, y=score, color=comModel)) + labs(title='Boxplot of models before (B) and after (T) transfer learning') + geom_boxplot(outlier.colour="red", outlier.shape=8,           outlier.size=4)
rq1_plot_box1
ggsave("rq1_boxplot.png")

p <- ggplot(df2, aes(x=comModel, y=score, color=TeD, group=TeD)) + labs(title='Lineplot of models before (B) and after (T) transfer learning') + geom_line(linetype="dashed")
p
ggsave("rq1_lines.png")

# Research Question 2
### What is the effect of different strategies to simultaneously learn one model from multiple TrDs?

ggplot(df2, aes(group=TeD, fill=TeD, y=score)) + geom_boxplot() + labs(title='Boxplots of Score per Test Set')
ggsave('rq2_testboxplot.png')

# Boxplot of score per transfer model
p <- ggplot(T_set, aes(group=model, fill=model, y=score)) + geom_boxplot() + labs(title='Boxplots of Score per Transfer Model')

p
ggsave("rq2_boxplot.png")
# Linear Model
mod1 = lm(score ~ model, data=T_set)
anova(mod1)
summary(mod1)

pairwise.t.test(T_set$score, T_set$model, p.adj = "holm")
TukeyHSD(aov(score ~ model, T_set))
p = ggplot(T_set, aes(score, colour=TeD)) + geom_density() + labs(title='Score Density Distribution of Test Sets for Combined Transfer Model')
p
ggsave('rq2_density_distribution.png')


p2 = ggplot(T_set, aes(score, colour=model)) + geom_density() + labs(title='Score Density Distribution of Transfer Models')
p2
ggsave('rq2_density_distribution2.png')

# Research Question 3
### What is the effect of the TrDs on the final model performance?
# Linear Model for training sets

TrD1 = df[which(df$TrD1 == 1),]
TrD2 = df[which(df$TrD2 == 1),]
TrD3 = df[which(df$TrD3 == 1),]
TrD4 = df[which(df$TrD4 == 1),]
TrD5 = df[which(df$TrD5 == 1),]
TrD6 = df[which(df$TrD6 == 1),]
TrD7 = df[which(df$TrD7 == 1),]
TrD8 = df[which(df$TrD8 == 1),]

# Distribution of score based on using training set
plot (density(TrD1$score), main='Distribution score per training set')
lines (density(TrD2$score))
lines (density(TrD3$score))
lines (density(TrD4$score))
lines (density(TrD5$score))
lines (density(TrD6$score))
lines (density(TrD7$score))
lines (density(TrD8$score))

mod1 = lm(score ~ TrD1, data=T_set)
anova(mod1)
summary(mod1)

mod2 = lm(score ~ TrD2, data=T_set)
anova(mod2)
summary(mod2)

mod2 = lm(score ~ TrD3, data=T_set)
anova(mod2)
summary(mod2)

mod2 = lm(score ~ TrD4, data=T_set)
anova(mod2)
summary(mod2)

mod2 = lm(score ~ TrD5, data=T_set)
anova(mod2)
summary(mod2)

mod2 = lm(score ~ TrD6, data=T_set)
anova(mod2)
summary(mod2)

mod2 = lm(score ~ TrD7, data=T_set)
anova(mod2)
summary(mod2)

mod2 = lm(score ~ TrD8, data=T_set)
anova(mod2)
summary(mod2)
